Implement PLA and Pocket PLA based on python3 on jupyter notebook.

Package: 
numpy, pandas, random, matplotlib.pyplot, statistics

Note: 
please put .ipynb and hw1_6_train.dat, hw1_7_train.dat, hw1_7_test.dat under the same path 