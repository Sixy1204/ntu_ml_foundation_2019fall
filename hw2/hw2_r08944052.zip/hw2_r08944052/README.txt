hw2_q7_q8.ipynb
package：random, numpy, matplotlib.pyplot
Please set Iter (iteration times) and data_size in the 5th block
By default Iter=1000, in question 7 data_size=20 and in question 8 data_size=2000 