Implement gradient descent（learning rate=0.01） and  stochastic gradient descent （learning rate=0.001）
for logistic regression based on python3 on jupyter notebook.

Package: 
numpy, matplotlib.pyplot

Note: 
please put hw3_q7_q8.ipynb, hw3_train.dat and hw3_test.dat under the same path 